from .email import Email


class Cc(Email):
    """A cc email address with an optional name."""
